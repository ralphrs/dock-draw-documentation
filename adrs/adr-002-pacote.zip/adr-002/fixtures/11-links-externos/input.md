---
dok: 1
id: 0192f0a1-5c3e-7a10-8b2c-3d4e5f607182
title: Fixture 11
---

[Docs](https://docs.astro.build "Astro") <https://supabase.com> https://github.com e [email](mailto:time@exemplo.com) ou time@exemplo.com.
